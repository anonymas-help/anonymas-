const axios = require('axios');
async function getToken(){
  const url = process.env.MTN_AUTH_URL;
  const clientId = process.env.MTN_CLIENT_ID;
  const clientSecret = process.env.MTN_CLIENT_SECRET;
  const resp = await axios.post(url, {client_id:clientId, client_secret:clientSecret, grant_type:'client_credentials'});
  return resp.data.access_token || resp.data.accessToken || null;
}
async function initiateRequestToPay(msisdn, amount, txId){
  const token = await getToken();
  const url = process.env.MTN_REQUESTTOPAY_URL;
  const payload = {
    amount: amount.toString(),
    currency: 'XOF',
    externalId: txId,
    payer: {partyIdType: 'MSISDN', partyId: msisdn},
    payerMessage: 'Abonnement ANONYMAS HELP',
    payeeNote: 'Subscription'
  };
  const headers = { Authorization: `Bearer ${token}`, 'X-Callback-Url': process.env.PAYMENT_WEBHOOK_URL };
  const r = await axios.post(url, payload, {headers});
  return r.data || {status:'initiated'};
}
module.exports = { getToken, initiateRequestToPay };
