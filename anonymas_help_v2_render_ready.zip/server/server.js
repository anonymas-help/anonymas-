require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid');
const jwt = require('jsonwebtoken');
const path = require('path');
const mtn = require('./utils/mtn');
const moov = require('./utils/moov');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname,'public')));

// simple in-memory stores (replace with DB in production)
const sessions = {};
const messages = {};
const payments = {};

// Admin login (use env vars)
app.post('/api/admin/login', (req,res)=>{
  const {username,password} = req.body;
  const adminUser = process.env.ADMIN_USER || 'admin';
  const adminPass = process.env.ADMIN_PASS || 'ChangeMe123!';
  if(username===adminUser && password===adminPass){
    const token = jwt.sign({role:'admin',user:username}, process.env.JWT_SECRET || 'devsecret', {expiresIn:'12h'});
    return res.json({ok:true,token});
  }
  return res.status(401).json({error:'invalid'});
});

// auth anonymous session
app.post('/api/auth/anonymous',(req,res)=>{
  const id = uuidv4();
  sessions[id] = {id,createdAt: Date.now()};
  res.json({sessionId:id});
});

// chat message (prototype)
app.post('/api/chat/message',(req,res)=>{
  const {sessionId,text} = req.body;
  if(!sessionId||!text) return res.status(400).json({error:'missing'});
  messages[sessionId]=messages[sessionId]||[];
  const m={id:uuidv4(),text,from:'user',createdAt:Date.now()};
  messages[sessionId].push(m);
  const reply={id:uuidv4(),text:'Merci, un conseiller vous répondra bientôt.',from:'advisor',createdAt:Date.now()};
  messages[sessionId].push(reply);
  res.json({ok:true,reply});
});

// init subscription/payment - will call provider helper modules
app.post('/api/subscription/init', async (req,res)=>{
  const {sessionId,plan,msisdn,provider} = req.body;
  if(!sessionId||!plan||!msisdn) return res.status(400).json({error:'missing'});
  const txId = uuidv4();
  payments[txId] = {id:txId,sessionId,plan,msisdn,provider,status:'pending',createdAt:Date.now()};
  try{
    let resp;
    if(provider==='mtn'){
      resp = await mtn.initiateRequestToPay(msisdn, plan.amount, txId);
    } else {
      resp = await moov.initiateCollection(msisdn, plan.amount, txId);
    }
    payments[txId].providerResponse = resp;
    res.json({ok:true,txId,providerResponse:resp});
  }catch(err){
    console.error('payment init error',err.message||err);
    res.status(500).json({error:'payment_failed'});
  }
});

// get payment status
app.get('/api/payments/:txId/status',(req,res)=>{
  const p = payments[req.params.txId];
  if(!p) return res.status(404).json({error:'not_found'});
  res.json({ok:true,status:p.status,providerResponse:p.providerResponse});
});

// webhook endpoint for providers to call
app.post('/api/payments/webhook',(req,res)=>{
  // In production validate signature / HMAC here
  const payload = req.body;
  console.log('webhook received',payload);
  // Example payload should include txId and status
  const {txId,status} = payload;
  if(txId && payments[txId]){
    payments[txId].status = status || 'completed';
    return res.json({ok:true});
  }
  res.json({ok:false});
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, ()=>console.log('Server running on',PORT));
