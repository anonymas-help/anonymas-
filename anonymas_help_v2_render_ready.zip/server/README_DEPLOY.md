# Deploying to Render (example)
1. Create a Render Web Service (Node) and link to repository.
2. Set Environment Variables in Render dashboard using values from .env.example (do NOT commit secrets).
3. Deploy branch; set start command: `npm start` in server folder.
4. For frontend, create a separate Static Site on Render/Vercel and build with `npm run build` then serve the build; or serve frontend with Vercel and set proxy to backend URL.
5. Configure webhook URL in MTN & Moov dashboards to point to: `https://<your-backend>/api/payments/webhook`
