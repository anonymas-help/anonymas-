# ANONYMAS HELP — Render-ready package (v2)

This package contains frontend (React + Vite) and backend (Node + Express) updated to include:
- MTN MoMo and Moov integration helpers (sandbox placeholders)
- Admin login endpoint (env-controlled)
- Webhook endpoint for payment callbacks
- Deployment notes and Render config example

IMPORTANT: Add real secret values in your Render (or hosting) environment variables; never commit secrets to git.
