import React, {useState} from 'react';
import axios from 'axios';
export default function App(){
  const [adminToken, setAdminToken] = useState(null);
  const [user, setUser] = useState('');
  const [pass, setPass] = useState('');
  async function loginAdmin(){
    try{
      const r = await axios.post('/api/admin/login',{username:user,password:pass});
      setAdminToken(r.data.token);
      alert('Connected as admin');
    }catch(e){ alert('Login failed') }
  }
  return (<div style={{fontFamily:'sans-serif',padding:20}}>
    <h1>ANONYMAS HELP — Prototype</h1>
    {!adminToken ? (
      <div style={{maxWidth:360}}>
        <h3>Admin login</h3>
        <input placeholder="username" value={user} onChange={e=>setUser(e.target.value)}/><br/>
        <input placeholder="password" type="password" value={pass} onChange={e=>setPass(e.target.value)}/><br/>
        <button onClick={loginAdmin}>Login</button>
      </div>
    ) : <div>Admin connected. Token: {adminToken}</div>}
  </div>)
}
